﻿namespace TripleArc
{
    partial class TripleArc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Dedendum 01");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Dedendum 02");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Addendum 01");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Addedndum 02");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Upper");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("FS Tooth (Parts)", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4,
            treeNode5});
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Base Curve");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("FS Tooth Base Motion");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("FS Envelop");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Addendum 01");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Addendum 02");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Dedendum 01");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Dedendum 02");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("CS Tooth (Parts)", new System.Windows.Forms.TreeNode[] {
            treeNode10,
            treeNode11,
            treeNode12,
            treeNode13});
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("k=0.9");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("k=1");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("k=1.1");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Circular Splines (Deflection)", new System.Windows.Forms.TreeNode[] {
            treeNode15,
            treeNode16,
            treeNode17});
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Deformed Flex Spline");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("FS Tooth Path");
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("FS Envelop (New)");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("FS Tooth New Motion");
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Teeth");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Ring Gear ");
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("FsToothCenterLines");
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("V Teeth CS", new System.Windows.Forms.TreeNode[] {
            treeNode23,
            treeNode24,
            treeNode25});
            this.zedGraphControlTripleArc = new ZedGraph.ZedGraphControl();
            this.treeViewTripleArc = new System.Windows.Forms.TreeView();
            this.labelCsTeeth = new System.Windows.Forms.Label();
            this.labelFsTeeth = new System.Windows.Forms.Label();
            this.labelModule = new System.Windows.Forms.Label();
            this.labelCsPitchDiameter = new System.Windows.Forms.Label();
            this.labelDeflection = new System.Windows.Forms.Label();
            this.labelCamAngle = new System.Windows.Forms.Label();
            this.labelCamIncrement = new System.Windows.Forms.Label();
            this.textBoxCsTeethCount = new System.Windows.Forms.TextBox();
            this.textBoxFsTeethCount = new System.Windows.Forms.TextBox();
            this.textBoxModule = new System.Windows.Forms.TextBox();
            this.textBoxCsPitchDiameter = new System.Windows.Forms.TextBox();
            this.textBoxDeflection = new System.Windows.Forms.TextBox();
            this.textBoxCamAngle = new System.Windows.Forms.TextBox();
            this.textBoxCamIncrement = new System.Windows.Forms.TextBox();
            this.buttonDecrement = new System.Windows.Forms.Button();
            this.buttonIncrement = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // zedGraphControlTripleArc
            // 
            this.zedGraphControlTripleArc.Location = new System.Drawing.Point(654, 13);
            this.zedGraphControlTripleArc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.zedGraphControlTripleArc.Name = "zedGraphControlTripleArc";
            this.zedGraphControlTripleArc.ScrollGrace = 0D;
            this.zedGraphControlTripleArc.ScrollMaxX = 0D;
            this.zedGraphControlTripleArc.ScrollMaxY = 0D;
            this.zedGraphControlTripleArc.ScrollMaxY2 = 0D;
            this.zedGraphControlTripleArc.ScrollMinX = 0D;
            this.zedGraphControlTripleArc.ScrollMinY = 0D;
            this.zedGraphControlTripleArc.ScrollMinY2 = 0D;
            this.zedGraphControlTripleArc.Size = new System.Drawing.Size(886, 737);
            this.zedGraphControlTripleArc.TabIndex = 0;
            // 
            // treeViewTripleArc
            // 
            this.treeViewTripleArc.CheckBoxes = true;
            this.treeViewTripleArc.Location = new System.Drawing.Point(338, 12);
            this.treeViewTripleArc.Name = "treeViewTripleArc";
            treeNode1.Checked = true;
            treeNode1.Name = "NodeFsDedundum1";
            treeNode1.Text = "Dedendum 01";
            treeNode2.Checked = true;
            treeNode2.Name = "NodeFsDedendum2";
            treeNode2.Text = "Dedendum 02";
            treeNode3.Checked = true;
            treeNode3.Name = "NodeFsAddendum1";
            treeNode3.Text = "Addendum 01";
            treeNode4.Checked = true;
            treeNode4.Name = "NodeFsAddedndum2";
            treeNode4.Text = "Addedndum 02";
            treeNode5.Checked = true;
            treeNode5.Name = "NodeFsUpper";
            treeNode5.Text = "Upper";
            treeNode6.Name = "NodeFsTeethParts";
            treeNode6.Text = "FS Tooth (Parts)";
            treeNode7.Name = "NodeBaseCurve";
            treeNode7.Text = "Base Curve";
            treeNode8.Name = "NodeMovingFSTBM";
            treeNode8.Text = "FS Tooth Base Motion";
            treeNode9.Name = "NodeFSE";
            treeNode9.Text = "FS Envelop";
            treeNode10.Checked = true;
            treeNode10.Name = "NodeCsAddendum1";
            treeNode10.Text = "Addendum 01";
            treeNode11.Checked = true;
            treeNode11.Name = "NodeCsAddendum2";
            treeNode11.Text = "Addendum 02";
            treeNode12.Checked = true;
            treeNode12.Name = "NodeCsDedendum1";
            treeNode12.Text = "Dedendum 01";
            treeNode13.Checked = true;
            treeNode13.Name = "NodeCsDedendum02";
            treeNode13.Text = "Dedendum 02";
            treeNode14.Name = "NodeCsToothParts";
            treeNode14.Text = "CS Tooth (Parts)";
            treeNode15.Name = "Nodek=0.9";
            treeNode15.Text = "k=0.9";
            treeNode16.Name = "Nodek=1";
            treeNode16.Text = "k=1";
            treeNode17.Name = "Nodek=1.1";
            treeNode17.Text = "k=1.1";
            treeNode18.Name = "NodeCsWithK";
            treeNode18.Text = "Circular Splines (Deflection)";
            treeNode19.Name = "NodeDeformedFlexSpline";
            treeNode19.Text = "Deformed Flex Spline";
            treeNode20.Name = "NodeFSTP";
            treeNode20.Text = "FS Tooth Path";
            treeNode21.Name = "NodeFSEN";
            treeNode21.Text = "FS Envelop (New)";
            treeNode22.Name = "NodeFSTNM";
            treeNode22.Text = "FS Tooth New Motion";
            treeNode23.Name = "NodeTeeth";
            treeNode23.Text = "Teeth";
            treeNode24.Name = "NodeRingGear";
            treeNode24.Text = "Ring Gear ";
            treeNode25.Name = "NodeFsToothCenterLines";
            treeNode25.Text = "FsToothCenterLines";
            treeNode26.Name = "NodeVTCS";
            treeNode26.Text = "V Teeth CS";
            this.treeViewTripleArc.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode6,
            treeNode7,
            treeNode8,
            treeNode9,
            treeNode14,
            treeNode18,
            treeNode19,
            treeNode20,
            treeNode21,
            treeNode22,
            treeNode26});
            this.treeViewTripleArc.Size = new System.Drawing.Size(309, 720);
            this.treeViewTripleArc.TabIndex = 1;
            this.treeViewTripleArc.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.treeViewTripleArc_AfterCheck);
            // 
            // labelCsTeeth
            // 
            this.labelCsTeeth.AutoSize = true;
            this.labelCsTeeth.Location = new System.Drawing.Point(12, 130);
            this.labelCsTeeth.Name = "labelCsTeeth";
            this.labelCsTeeth.Size = new System.Drawing.Size(140, 17);
            this.labelCsTeeth.TabIndex = 2;
            this.labelCsTeeth.Text = "Circular Spline Teeth";
            // 
            // labelFsTeeth
            // 
            this.labelFsTeeth.AutoSize = true;
            this.labelFsTeeth.Location = new System.Drawing.Point(12, 170);
            this.labelFsTeeth.Name = "labelFsTeeth";
            this.labelFsTeeth.Size = new System.Drawing.Size(117, 17);
            this.labelFsTeeth.TabIndex = 3;
            this.labelFsTeeth.Text = "Flex Spline Teeth";
            // 
            // labelModule
            // 
            this.labelModule.AutoSize = true;
            this.labelModule.Location = new System.Drawing.Point(12, 210);
            this.labelModule.Name = "labelModule";
            this.labelModule.Size = new System.Drawing.Size(54, 17);
            this.labelModule.TabIndex = 4;
            this.labelModule.Text = "Module";
            // 
            // labelCsPitchDiameter
            // 
            this.labelCsPitchDiameter.AutoSize = true;
            this.labelCsPitchDiameter.Location = new System.Drawing.Point(12, 250);
            this.labelCsPitchDiameter.Name = "labelCsPitchDiameter";
            this.labelCsPitchDiameter.Size = new System.Drawing.Size(195, 17);
            this.labelCsPitchDiameter.TabIndex = 5;
            this.labelCsPitchDiameter.Text = "Circular Spline Pitch Diameter";
            // 
            // labelDeflection
            // 
            this.labelDeflection.AutoSize = true;
            this.labelDeflection.Location = new System.Drawing.Point(12, 290);
            this.labelDeflection.Name = "labelDeflection";
            this.labelDeflection.Size = new System.Drawing.Size(71, 17);
            this.labelDeflection.TabIndex = 6;
            this.labelDeflection.Text = "Deflection";
            // 
            // labelCamAngle
            // 
            this.labelCamAngle.AutoSize = true;
            this.labelCamAngle.Location = new System.Drawing.Point(12, 330);
            this.labelCamAngle.Name = "labelCamAngle";
            this.labelCamAngle.Size = new System.Drawing.Size(76, 17);
            this.labelCamAngle.TabIndex = 7;
            this.labelCamAngle.Text = "Cam Angle";
            // 
            // labelCamIncrement
            // 
            this.labelCamIncrement.AutoSize = true;
            this.labelCamIncrement.Location = new System.Drawing.Point(12, 370);
            this.labelCamIncrement.Name = "labelCamIncrement";
            this.labelCamIncrement.Size = new System.Drawing.Size(102, 17);
            this.labelCamIncrement.TabIndex = 8;
            this.labelCamIncrement.Text = "Cam Increment";
            // 
            // textBoxCsTeethCount
            // 
            this.textBoxCsTeethCount.Location = new System.Drawing.Point(218, 130);
            this.textBoxCsTeethCount.Name = "textBoxCsTeethCount";
            this.textBoxCsTeethCount.Size = new System.Drawing.Size(100, 22);
            this.textBoxCsTeethCount.TabIndex = 9;
            this.textBoxCsTeethCount.Text = "102";
            this.textBoxCsTeethCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxCsTeethCount.TextChanged += new System.EventHandler(this.textBoxCsTeethCount_TextChanged);
            // 
            // textBoxFsTeethCount
            // 
            this.textBoxFsTeethCount.Enabled = false;
            this.textBoxFsTeethCount.Location = new System.Drawing.Point(218, 170);
            this.textBoxFsTeethCount.Name = "textBoxFsTeethCount";
            this.textBoxFsTeethCount.Size = new System.Drawing.Size(100, 22);
            this.textBoxFsTeethCount.TabIndex = 10;
            this.textBoxFsTeethCount.Text = "100";
            this.textBoxFsTeethCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxFsTeethCount.TextChanged += new System.EventHandler(this.textBoxFsTeethCount_TextChanged);
            // 
            // textBoxModule
            // 
            this.textBoxModule.Location = new System.Drawing.Point(218, 210);
            this.textBoxModule.Name = "textBoxModule";
            this.textBoxModule.ReadOnly = true;
            this.textBoxModule.Size = new System.Drawing.Size(100, 22);
            this.textBoxModule.TabIndex = 11;
            this.textBoxModule.Text = "0.25";
            this.textBoxModule.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxModule.TextChanged += new System.EventHandler(this.textBoxModule_TextChanged);
            // 
            // textBoxCsPitchDiameter
            // 
            this.textBoxCsPitchDiameter.Location = new System.Drawing.Point(218, 250);
            this.textBoxCsPitchDiameter.Name = "textBoxCsPitchDiameter";
            this.textBoxCsPitchDiameter.Size = new System.Drawing.Size(100, 22);
            this.textBoxCsPitchDiameter.TabIndex = 12;
            this.textBoxCsPitchDiameter.Text = "52";
            this.textBoxCsPitchDiameter.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxCsPitchDiameter.TextChanged += new System.EventHandler(this.textBoxCsPitchDiameter_TextChanged);
            // 
            // textBoxDeflection
            // 
            this.textBoxDeflection.Location = new System.Drawing.Point(218, 290);
            this.textBoxDeflection.Name = "textBoxDeflection";
            this.textBoxDeflection.Size = new System.Drawing.Size(100, 22);
            this.textBoxDeflection.TabIndex = 13;
            this.textBoxDeflection.Text = "1";
            this.textBoxDeflection.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxDeflection.TextChanged += new System.EventHandler(this.textBoxDeflection_TextChanged);
            // 
            // textBoxCamAngle
            // 
            this.textBoxCamAngle.Location = new System.Drawing.Point(218, 330);
            this.textBoxCamAngle.Name = "textBoxCamAngle";
            this.textBoxCamAngle.ReadOnly = true;
            this.textBoxCamAngle.Size = new System.Drawing.Size(100, 22);
            this.textBoxCamAngle.TabIndex = 14;
            this.textBoxCamAngle.Text = "0";
            this.textBoxCamAngle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxCamIncrement
            // 
            this.textBoxCamIncrement.Location = new System.Drawing.Point(218, 370);
            this.textBoxCamIncrement.Name = "textBoxCamIncrement";
            this.textBoxCamIncrement.Size = new System.Drawing.Size(100, 22);
            this.textBoxCamIncrement.TabIndex = 15;
            this.textBoxCamIncrement.Text = "5";
            this.textBoxCamIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // buttonDecrement
            // 
            this.buttonDecrement.Location = new System.Drawing.Point(195, 413);
            this.buttonDecrement.Name = "buttonDecrement";
            this.buttonDecrement.Size = new System.Drawing.Size(60, 60);
            this.buttonDecrement.TabIndex = 16;
            this.buttonDecrement.Text = "-";
            this.buttonDecrement.UseVisualStyleBackColor = true;
            this.buttonDecrement.Click += new System.EventHandler(this.buttonDecrement_Click);
            // 
            // buttonIncrement
            // 
            this.buttonIncrement.Location = new System.Drawing.Point(261, 413);
            this.buttonIncrement.Name = "buttonIncrement";
            this.buttonIncrement.Size = new System.Drawing.Size(60, 60);
            this.buttonIncrement.TabIndex = 17;
            this.buttonIncrement.Text = "+";
            this.buttonIncrement.UseVisualStyleBackColor = true;
            this.buttonIncrement.Click += new System.EventHandler(this.buttonIncrement_Click);
            // 
            // TripleArc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1553, 763);
            this.Controls.Add(this.buttonIncrement);
            this.Controls.Add(this.buttonDecrement);
            this.Controls.Add(this.textBoxCamIncrement);
            this.Controls.Add(this.textBoxCamAngle);
            this.Controls.Add(this.textBoxDeflection);
            this.Controls.Add(this.textBoxCsPitchDiameter);
            this.Controls.Add(this.textBoxModule);
            this.Controls.Add(this.textBoxFsTeethCount);
            this.Controls.Add(this.textBoxCsTeethCount);
            this.Controls.Add(this.labelCamIncrement);
            this.Controls.Add(this.labelCamAngle);
            this.Controls.Add(this.labelDeflection);
            this.Controls.Add(this.labelCsPitchDiameter);
            this.Controls.Add(this.labelModule);
            this.Controls.Add(this.labelFsTeeth);
            this.Controls.Add(this.labelCsTeeth);
            this.Controls.Add(this.treeViewTripleArc);
            this.Controls.Add(this.zedGraphControlTripleArc);
            this.Name = "TripleArc";
            this.Text = "Triple Arc";
            this.Load += new System.EventHandler(this.Triple_Arc_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ZedGraph.ZedGraphControl zedGraphControlTripleArc;
        private System.Windows.Forms.TreeView treeViewTripleArc;
        private System.Windows.Forms.Label labelCsTeeth;
        private System.Windows.Forms.Label labelFsTeeth;
        private System.Windows.Forms.Label labelModule;
        private System.Windows.Forms.Label labelCsPitchDiameter;
        private System.Windows.Forms.Label labelDeflection;
        private System.Windows.Forms.Label labelCamAngle;
        private System.Windows.Forms.Label labelCamIncrement;
        private System.Windows.Forms.TextBox textBoxCsTeethCount;
        private System.Windows.Forms.TextBox textBoxFsTeethCount;
        private System.Windows.Forms.TextBox textBoxModule;
        private System.Windows.Forms.TextBox textBoxCsPitchDiameter;
        private System.Windows.Forms.TextBox textBoxDeflection;
        private System.Windows.Forms.TextBox textBoxCamAngle;
        private System.Windows.Forms.TextBox textBoxCamIncrement;
        private System.Windows.Forms.Button buttonDecrement;
        private System.Windows.Forms.Button buttonIncrement;
    }
}

