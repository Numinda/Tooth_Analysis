﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZedGraph;
using CSML;

namespace TripleArc
{
    public partial class TripleArc : Form
    {
        //classes
        Triple_Arc gear = new Triple_Arc();

        //creating pointpairlists

        //flex spline tooth//
        PointPairList FsDedendum1 = new PointPairList();
        PointPairList FsDedendum2 = new PointPairList();
        PointPairList FsAddendum1 = new PointPairList();
        PointPairList FsAddendum2 = new PointPairList();
        PointPairList FsUpper = new PointPairList();
        PointPairList FsDedendum1Mirror = new PointPairList();
        PointPairList FsDedendum2Mirror = new PointPairList();
        PointPairList FsAddendum1Mirror = new PointPairList();
        PointPairList FsAddendum2Mirror = new PointPairList();
        PointPairList FsUpperMirror = new PointPairList();
        PointPairList FsHalfTooth = new PointPairList();
        PointPairList FsHalfToothMirror = new PointPairList();
        PointPairList FsFullTooth = new PointPairList();

        //circular spline tooth//
        PointPairList CsAddendum1 = new PointPairList();
        PointPairList CsAddendum2 = new PointPairList();
        PointPairList CsDedendum1 = new PointPairList();
        PointPairList CsDedendum2 = new PointPairList();
        PointPairList CsAddendum1Mirror = new PointPairList();
        PointPairList CsAddendum2Mirror = new PointPairList();
        PointPairList CsDedendum1Mirror = new PointPairList();
        PointPairList CsDedendum2Mirror = new PointPairList();

        //circular spline  V tooth for test
        PointPairList VeeCsFlank = new PointPairList();
        PointPairList VeeCsFlankMirror = new PointPairList();
        PointPairList VeeCsFullTooth = new PointPairList();
        PointPairList VeeCsFullToothTranslated = new PointPairList();
        PointPairList VeeCsRingGear = new PointPairList();

        //FS Center lines
        PointPairList FsToothTopCenter = new PointPairList();
        PointPairList FsToothCenterLine = new PointPairList();
        PointPairList DeformedFSCenterLines = new PointPairList();

        //shifting the flex spline tooth//
        PointPairList ShiftedFsFullToothBaseMotion = new PointPairList();
        PointPairList ShiftedFsFullToothNewMotion = new PointPairList();
        PointPairList FsFullToothTipMotion = new PointPairList();

        //Base Curve//
        PointPairList BaseCurve = new PointPairList();

        //FS Teeth motion on Base curve//
        PointPairList FSToothBaseCurveMotion = new PointPairList();

        //Deformed FS//
        PointPairList DeformedFS = new PointPairList();


        //FS Teeth motion on new curve//
        PointPairList FSToothNewMotion = new PointPairList();


        GraphPane myGraphPane;
        public TripleArc()
        {
            InitializeComponent();
            drawGraph();
        }
        private void Triple_Arc_Load(object sender, EventArgs e)
        {
            myGraphPane = zedGraphControlTripleArc.GraphPane;
            drawGraph();
        }
        private void drawGraph()
        {

            TreeNodeCollection nodes = treeViewTripleArc.Nodes;
            myGraphPane = zedGraphControlTripleArc.GraphPane;
            myGraphPane.CurveList.Clear();

            //parameters//
            double pitchdia = double.Parse(textBoxCsPitchDiameter.Text);
            double camangle = double.Parse(textBoxCamAngle.Text);
            double deflection = double.Parse(textBoxDeflection.Text);
            int csteeth = int.Parse(textBoxCsTeethCount.Text);
            int fsteeth = csteeth - 2;

            textBoxFsTeethCount.Text = fsteeth.ToString();
            double module = pitchdia / csteeth;
            textBoxModule.Text = module.ToString();


            //Flex spline tooth//
            FsDedendum1 = gear.CreateFsDedendum1(module);
            FsDedendum2 = gear.CreateFsDedendum2(module);
            FsAddendum1 = gear.CreateFsAddendum1(module);
            FsAddendum2 = gear.CreateFsAddendum2(module);
            FsUpper = gear.CreateFsUpper(module);
            FsDedendum1Mirror = gear.Mirror(FsDedendum1);
            FsDedendum2Mirror = gear.Mirror(FsDedendum2);
            FsAddendum1Mirror = gear.Mirror(FsAddendum1);
            FsAddendum2Mirror = gear.Mirror(FsAddendum2);
            FsUpperMirror = gear.Mirror(FsUpper);
            FsHalfTooth = gear.CreateHalfTooth(FsDedendum1, FsDedendum2, FsAddendum1, FsAddendum2, FsUpper);
            FsHalfToothMirror = gear.Mirror(FsHalfTooth);
            FsFullTooth = gear.CreateFullTooth(FsHalfTooth, FsHalfToothMirror);


            //Base Curve//
            BaseCurve = gear.CreatepathTopCenter(deflection, module);

            //FS tootth Motion on the Base Curve//
            FSToothBaseCurveMotion = gear.FSTeethBaseCurveMotion(FsFullTooth, deflection, module, camangle);


            //circular spline tooth//
            CsAddendum1 = gear.CreateCsAddendum1(module, 0.9);
            CsAddendum2 = gear.CreateCsAddendum2(module, 0.9);
            CsDedendum1 = gear.CreateCsDedendum1(module, 1.1);
            CsDedendum2 = gear.CreateCsDedendum2(module, 1.1);
            CsAddendum1Mirror = gear.Mirror(CsAddendum1);
            CsAddendum2Mirror = gear.Mirror(CsAddendum2);
            CsDedendum1Mirror = gear.Mirror(CsDedendum1);
            CsDedendum2Mirror = gear.Mirror(CsDedendum2);

            //DEformed FS//
            DeformedFS = gear.DeformGear(FsFullTooth, deflection, module, 0, fsteeth);

            //FS tootth Motion on new Curve//
            FSToothNewMotion = gear.FSTeethNewMotion(FsFullTooth, deflection, module, camangle, fsteeth);

            //Test circular spline tooth
            VeeCsFlank = gear.CreateVeeCsFlank(module);
            VeeCsFlankMirror = gear.Mirror(VeeCsFlank);
            VeeCsFullTooth = gear.CreateFullTooth(VeeCsFlank, VeeCsFlankMirror);
            VeeCsFullToothTranslated = gear.Translate(VeeCsFullTooth, pitchdia / 2);
            VeeCsRingGear = gear.Rotate(VeeCsFullToothTranslated,csteeth);

            FsToothTopCenter = gear.CreateFSToothTopCenter(module);
            FsToothCenterLine = gear.CreateFSToothCenterLine(module);

            //nodes
            if (nodes[0].Checked)
            {
                if (nodes[0].Nodes[0].Checked)
                {
                    myGraphPane.AddCurve("", FsDedendum1, Color.Black, SymbolType.None);
                    myGraphPane.AddCurve("", FsDedendum1Mirror, Color.Black, SymbolType.None);
                }
                if (nodes[0].Nodes[1].Checked)
                {
                    myGraphPane.AddCurve("", FsDedendum2, Color.Blue, SymbolType.None);
                    myGraphPane.AddCurve("", FsDedendum2Mirror, Color.Blue, SymbolType.None);
                }
                if (nodes[0].Nodes[2].Checked)
                {
                    myGraphPane.AddCurve("", FsAddendum1, Color.Red, SymbolType.None);
                    myGraphPane.AddCurve("", FsAddendum1Mirror, Color.Red, SymbolType.None);
                }
                if (nodes[0].Nodes[3].Checked)
                {
                    myGraphPane.AddCurve("", FsAddendum2, Color.Brown, SymbolType.None);
                    myGraphPane.AddCurve("", FsAddendum2Mirror, Color.Brown, SymbolType.None);
                }
                if (nodes[0].Nodes[4].Checked)
                {
                    myGraphPane.AddCurve("", FsUpper, Color.Blue, SymbolType.None);
                    myGraphPane.AddCurve("", FsUpperMirror, Color.Blue, SymbolType.None);
                }

            }
            if (nodes[1].Checked)
            {
                myGraphPane.AddCurve("", BaseCurve, Color.Blue, SymbolType.None);
            }

            if (nodes[2].Checked)
            {
                myGraphPane.AddCurve("", FSToothBaseCurveMotion, Color.Red, SymbolType.None);

            }
            if (nodes[3].Checked)
            {

                for (int theta = -90; theta <= 90; theta += 5)
                {
                    ShiftedFsFullToothBaseMotion = gear.FSTeethBaseCurveMotion(FsFullTooth, deflection, module, theta);
                    myGraphPane.AddCurve("", ShiftedFsFullToothBaseMotion, Color.Aqua, SymbolType.None);
                }

            }
            if (nodes[4].Checked)
            {
                if (nodes[4].Nodes[0].Checked)
                {
                    myGraphPane.AddCurve("", CsAddendum1, Color.Blue, SymbolType.None);
                    myGraphPane.AddCurve("", CsAddendum1Mirror, Color.Blue, SymbolType.None);
                }
                if (nodes[4].Nodes[1].Checked)
                {
                    myGraphPane.AddCurve("", CsAddendum2, Color.Blue, SymbolType.None);
                    myGraphPane.AddCurve("", CsAddendum2Mirror, Color.Blue, SymbolType.None);
                }
                if (nodes[4].Nodes[2].Checked)
                {
                    myGraphPane.AddCurve("", CsDedendum1, Color.Blue, SymbolType.None);
                    myGraphPane.AddCurve("", CsDedendum1Mirror, Color.Blue, SymbolType.None);
                }
                if (nodes[4].Nodes[3].Checked)
                {
                    myGraphPane.AddCurve("", CsDedendum2, Color.Blue, SymbolType.None);
                    myGraphPane.AddCurve("", CsDedendum2Mirror, Color.Blue, SymbolType.None);
                }
            }

            //node 5 missing code

            if (nodes[6].Checked)
            {
                myGraphPane.AddCurve("", DeformedFS, Color.Blue, SymbolType.None);
                
            }

            //         MessageBox.Show(FsToothTopCenter.Count.ToString());

            if (nodes[7].Checked)
            {
                FsFullToothTipMotion.Clear();
                for (int i = -fsteeth / 4; i <= fsteeth / 4; i = i + 1)
                {
                    PointPairList ToothTip = new PointPairList();
                    ToothTip = gear.DeformedFsReference(FsToothTopCenter, deflection, module, fsteeth, i);
                    FsFullToothTipMotion.Add(ToothTip);
                }
                myGraphPane.AddCurve("", FsFullToothTipMotion, Color.Red, SymbolType.None);
            }

            if (nodes[8].Checked)
            {

                for (int i = -fsteeth ; i <= fsteeth ; i = i+1)
                {
                    ShiftedFsFullToothNewMotion = gear.DeformedFsReference(FsFullTooth, deflection, module,fsteeth,i);
                    myGraphPane.AddCurve("", ShiftedFsFullToothNewMotion, Color.GreenYellow, SymbolType.None);
                }

            }
            if (nodes[9].Checked)
            {
                myGraphPane.AddCurve("", FSToothNewMotion, Color.Blue, SymbolType.None);
            }
            if (nodes[10].Checked)
            {
                if (nodes[10].Nodes[0].Checked)
                {
                    myGraphPane.AddCurve("", VeeCsFullTooth, Color.Blue, SymbolType.None);

                }
                if (nodes[10].Nodes[1].Checked)
                {
                    myGraphPane.AddCurve("", VeeCsRingGear, Color.Black, SymbolType.None);

                }
                if (nodes[10].Nodes[2].Checked)
                {
                    double theta;
                    myGraphPane.AddCurve("", FsToothCenterLine, Color.Black, SymbolType.None);
                    for (int i = 0; i <= fsteeth; i++ )
                    {
                        theta = i* 360 / fsteeth;
                        DeformedFSCenterLines.Add(gear.DeformedFsToothCentreLines(FsToothCenterLine, deflection, module, theta, fsteeth));
                  //      DeformedFSCenterLines.Add(gear.DeformedFsToothCentreLines(FsFullTooth, deflection, module, theta, fsteeth));

                    }
                    myGraphPane.AddCurve("", DeformedFSCenterLines, Color.Red, SymbolType.None);


                }

            }
            if (nodes[6].Checked||nodes[10].Nodes[1].Checked||nodes[10].Nodes[2].Checked)
            {
                //graph settings-zoom out to view the full ring gears
                myGraphPane.YAxis.Scale.MinAuto = false;
                myGraphPane.YAxis.Scale.MaxAuto = false;
                myGraphPane.YAxis.Scale.Min = -0.55 * pitchdia;
                myGraphPane.YAxis.Scale.Max = 0.55 * pitchdia;
                myGraphPane.XAxis.Scale.Min = -0.55 * pitchdia;
                myGraphPane.XAxis.Scale.Max = 0.55 * pitchdia;

                zedGraphControlTripleArc.AxisChange();
                zedGraphControlTripleArc.Invalidate();
            }
            else if (nodes[3].Checked||nodes[8].Checked)
            { 
                //graph settings-zoom in to view the shifted tooth
                myGraphPane.YAxis.Scale.MinAuto = false;
                myGraphPane.YAxis.Scale.MaxAuto = false;
                myGraphPane.YAxis.Scale.Min = -Math.PI * module;
                myGraphPane.YAxis.Scale.Max = Math.PI * module;
                myGraphPane.XAxis.Scale.Min = -Math.PI * module;
                myGraphPane.XAxis.Scale.Max = Math.PI * module;

                zedGraphControlTripleArc.AxisChange();
                zedGraphControlTripleArc.Invalidate();

            }
            else
            {
                //graph settings-zoom in to view the basic tooth
                myGraphPane.YAxis.Scale.MinAuto = false;
                myGraphPane.YAxis.Scale.MaxAuto = false;
                myGraphPane.YAxis.Scale.Min = -0.5 * Math.PI * module;
                myGraphPane.YAxis.Scale.Max = Math.PI * module;
                myGraphPane.XAxis.Scale.Min = -Math.PI * module;
                myGraphPane.XAxis.Scale.Max = Math.PI * module;

                zedGraphControlTripleArc.AxisChange();
                zedGraphControlTripleArc.Invalidate();
            }


        }

        private void textBoxCsTeethCount_TextChanged(object sender, EventArgs e)
        {
            double flexteeth = int.Parse(textBoxCsTeethCount.Text) - 2;
            textBoxFsTeethCount.Text = flexteeth.ToString();
            double module = float.Parse(textBoxCsPitchDiameter.Text) / int.Parse(textBoxCsTeethCount.Text);
            textBoxModule.Text = module.ToString();
            drawGraph();
        }

        private void textBoxFsTeethCount_TextChanged(object sender, EventArgs e)
        {
            double module = float.Parse(textBoxCsPitchDiameter.Text) / int.Parse(textBoxCsTeethCount.Text);
            textBoxModule.Text = module.ToString();
            drawGraph();
        }

        private void textBoxModule_TextChanged(object sender, EventArgs e)
        {

        }

        private void treeViewTripleArc_AfterCheck(object sender, TreeViewEventArgs e)
        {
            drawGraph();
        }

        private void textBoxCsPitchDiameter_TextChanged(object sender, EventArgs e)
        {
            double module = float.Parse(textBoxCsPitchDiameter.Text) / int.Parse(textBoxCsTeethCount.Text);
            textBoxModule.Text = module.ToString();
            drawGraph();
        }

        private void buttonIncrement_Click(object sender, EventArgs e)
        {
            double camangle = double.Parse(textBoxCamAngle.Text);
            camangle += double.Parse(textBoxCamIncrement.Text);
            textBoxCamAngle.Text = camangle.ToString();
            drawGraph();
        }

        private void buttonDecrement_Click(object sender, EventArgs e)
        {
            double camangle = double.Parse(textBoxCamAngle.Text);
            camangle -= float.Parse(textBoxCamIncrement.Text);
            textBoxCamAngle.Text = camangle.ToString();
            drawGraph();
        }

        private void textBoxDeflection_TextChanged(object sender, EventArgs e)
        {
            drawGraph();
        }

        
    }
}
